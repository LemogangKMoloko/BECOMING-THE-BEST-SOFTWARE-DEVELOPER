package com.example.demo.api;

import com.example.demo.model.Investor;
import com.example.demo.service.InvestorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("api/vi/Investor")
@RestController
public class InvestorController {

    private final InvestorService investorService;

    @Autowired
    public InvestorController(InvestorService investorService){
        this.investorService = investorService;
    }
//to insert data
    @PostMapping
    public void addInvestor(@RequestBody Investor investor){
        investorService.addInvestor(investor);
    }
//method serving as get request
    @GetMapping
public List<Investor> getAllPeople(){
        return investorService.getAllPeople();
}

}
