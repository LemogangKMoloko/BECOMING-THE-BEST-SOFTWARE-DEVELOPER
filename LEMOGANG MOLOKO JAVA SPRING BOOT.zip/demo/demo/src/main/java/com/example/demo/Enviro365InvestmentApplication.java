package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Enviro365InvestmentApplication {
	public static void main(String[] args) {
		SpringApplication.run(Enviro365InvestmentApplication.class, args);
	}

}
