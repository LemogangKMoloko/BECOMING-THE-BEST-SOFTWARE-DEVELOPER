package com.example.demo.dao;

import com.example.demo.model.Investor;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Repository("invDao")
public class InvestorDataAccess implements Investor_Dao{

    private static List<Investor> DB = new ArrayList<>();

    @Override
    public int insertInvestor(UUID id, Investor investor) {
        DB.add(new Investor(id, investor.getName(),
                investor.getSurname(), investor.getAge(),
                investor.getContact(),investor.getAddress(),
                investor.getProduct_id(), investor.getProduct_name(),
                investor.getProduct_type(), investor.getCurrent_balance()));
        return 1;
    }

    @Override
    public List<Investor> selectAllPeople() {
        return DB;
    }


}
