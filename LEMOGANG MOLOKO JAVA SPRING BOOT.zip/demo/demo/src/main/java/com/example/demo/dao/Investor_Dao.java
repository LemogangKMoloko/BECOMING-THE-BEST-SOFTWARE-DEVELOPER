package com.example.demo.dao;

import com.example.demo.model.Investor;

import java.util.List;
import java.util.UUID;

public interface Investor_Dao {
    int insertInvestor(UUID id,Investor investor);
    //inserting automated user ID
    default int insertInvestor(Investor investor){
        UUID id = UUID.randomUUID();
        return insertInvestor(id,investor);
    }

    //retrieving data from our database
    List<Investor> selectAllPeople();


}
