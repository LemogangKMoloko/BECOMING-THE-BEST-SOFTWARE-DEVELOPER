package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.UUID;

public class Investor {

//initializing
    private final UUID id;
    private final String name;
    private final String surname;
    private final String age;
    private final String contact;
    private final String address;

    //product data
    private final String product_name;
    private final String product_type;

    private final String product_id;

    private final String current_balance;

    //messaging



    private String savings_message = "you have requested a savings withdrawal";
    private String retirement_message= "you have requested a retirement withdrawal";



    public Investor(@JsonProperty("id") UUID id,@JsonProperty("name") String name,
                    @JsonProperty("surname")String surname,@JsonProperty("age") String age,
                    @JsonProperty("contact") String contact,@JsonProperty("address") String address,
                    @JsonProperty("product_id") String product_id,@JsonProperty("product_name") String product_name,
                    @JsonProperty("product_type") String product_type,@JsonProperty("current_balance") String current_balance) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.contact = contact;
        this.address = address;
        this.product_id = product_id;
        this.product_name = product_name;
        this.product_type = product_type;
        this.current_balance = current_balance;
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }
    public String getSurname() {
        return surname;
    }

    public String getAge() {
        return age;
    }

    public String getContact() {
        return contact;
    }

    public String getAddress() {
        return address;
    }

    //getters of the investment

    public String getProduct_name() {
        return product_name;
    }

    public String getProduct_id() {
        return product_id;
    }

    public String getProduct_type() {
        return product_type;
    }

    public String getCurrent_balance() {
        return current_balance;
    }

    public String getSavings_message() {

        return savings_message;
    }

    public void setSavings_message(String savings_message) {
        this.savings_message = savings_message;
    }
    public String getRetirement_message() {
        return retirement_message;
    }

    public void setRetirement_message(String retirement_message) {
        this.retirement_message = retirement_message;
    }
}
