package com.example.demo.service;

import com.example.demo.dao.Investor_Dao;
import com.example.demo.model.Investor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InvestorService {
    private final Investor_Dao investorDao;

    //injecting
    @Autowired
    public InvestorService(@Qualifier("invDao") Investor_Dao investorDao){
        this.investorDao = investorDao;
    }


    public int addInvestor(Investor investor){
        return investorDao.insertInvestor(investor);
    }

public List<Investor> getAllPeople(){
        return investorDao.selectAllPeople();
}
}
