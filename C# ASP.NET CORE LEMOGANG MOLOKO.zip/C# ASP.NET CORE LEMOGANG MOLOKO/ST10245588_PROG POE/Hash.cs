﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace ST10245588_PROG_POE
{
    public class HashPassword
    {
        public static string Hash(string password)
        {//save the password as hash
            SHA1CryptoServiceProvider obj = new SHA1CryptoServiceProvider();
            byte[] code = Encoding.ASCII.GetBytes(password);
            byte[] security = obj.ComputeHash(code);
            return Convert.ToBase64String(security);
        }
    }
}