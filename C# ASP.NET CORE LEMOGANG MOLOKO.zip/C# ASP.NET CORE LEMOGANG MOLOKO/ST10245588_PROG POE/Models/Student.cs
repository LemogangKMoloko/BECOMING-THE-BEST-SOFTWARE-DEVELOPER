﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Cryptography;
using System.Text;

namespace ST10245588_PROG_POE.Models
{
    public class Student
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Display(Name = "name")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "name required")]
        public string name { get; set; }

        [Display(Name = "surname")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "surname required")]
        public string surname { get; set; }

        [Display(Name = "studentNumber")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "studentNumber required")]
        public string studentNumber { get; set; }

        [Display(Name = "username")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "username required")]
        public string username { get; set; }

        [Display(Name = "password")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "password required")]
        public string password { get; set; }

        public string moduleCode { get; set; }
        public string moduleName { get; set; }
        public int credits { get; set; }
        public int hours { get; set; }
        public int weeks { get; set; }

        public DateTime startOfSemester { get; set; }
        public DateTime endOfSemester { get; set; }
        public int selfStudy { get; set; }
        public int moduleHours { get; set; }

        public DateTime moduleDate { get; set; }
        public int hoursRemaining { get; set; }

       

    }
}