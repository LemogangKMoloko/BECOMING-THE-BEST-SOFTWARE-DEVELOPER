﻿using Microsoft.VisualStudio.Services.Account;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;


namespace ST10245588_PROG_POE.Models
{
    public class StudentInfo
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public string moduleCode { get; set; }
        public string moduleName { get; set; }
        public int credits { get; set; }
        public int hours { get; set; }
        public int weeks { get; set; }

        public DateTime startOfSemester { get; set; }
        public DateTime endOfSemester { get; set; }
        public int selfStudy { get; set; }
        public int moduleHours { get; set; }

        public DateTime moduleDate { get; set; }
        public int hoursRemaining { get; set; }

        [Display(Name = "Student")]

        public string username { get; set; }
        [ForeignKey("username")]
        public virtual Account Student { get; set; }

    }
}