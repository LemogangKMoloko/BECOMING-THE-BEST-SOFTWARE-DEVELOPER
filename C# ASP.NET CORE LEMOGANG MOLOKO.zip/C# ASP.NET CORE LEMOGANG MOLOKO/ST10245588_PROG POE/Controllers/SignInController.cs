﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ST10245588_PROG_POE.Controllers;
using ST10245588_PROG_POE.Models;
using System.Data.SqlClient;
using System.Data;
using System.Windows;
using System.Windows.Forms;

namespace ST10245588_PROG_POE.Controllers
{
    public class SignInController : Controller
    {
        //creating a connection
        SqlConnection connect = new SqlConnection();
        SqlCommand command = new SqlCommand();
        SqlDataReader read;

        // GET: SignIn
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        //connection String
        void connectionString()
        {
            connect.ConnectionString = "Data Source=(localdb)\\ProjectsV13;Initial Catalog=TimeManagement;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        }

        [HttpPost]
        public ActionResult verifyStudent(Student stu)
        {
            connectionString();
            connect.Open();

            command.Connection = connect;

            command.CommandText = "Select * from StudentInformation where username = '" + stu.username + "' and password ='" + stu.password + "'"; 
            read = command.ExecuteReader();
            if (read.Read())
            {
                connect.Close();
                return View("addModules");

            }
            else
            {
                connect.Close();
                return View("Error");
            }
        }

        [HttpGet]
        public ActionResult registerStudent()
        {
            return View();
        }


        [HttpPost]
        //Registering Student
        public ActionResult registerStudent(Student stu)
        {
            connectionString();
            connect.Open();

            SqlDataAdapter da = new SqlDataAdapter("enterStudent", connect);

            //inserting data into databse
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@name", SqlDbType.VarChar, 20).Value = stu.name; //add these variables to model
            da.SelectCommand.Parameters.Add("@surname", SqlDbType.VarChar, 20).Value = stu.surname;
            da.SelectCommand.Parameters.Add("@studentNumber", SqlDbType.VarChar).Value = stu.studentNumber;
            da.SelectCommand.Parameters.Add("@username", SqlDbType.VarChar,10).Value = stu.username;
            da.SelectCommand.Parameters.Add("@password", SqlDbType.VarChar, 10).Value =HashPassword.Hash(stu.password); 
            da.SelectCommand.ExecuteNonQuery();
            MessageBox.Show("Student has been successfully registered.");

            connect.Close();
            return View("addModules"); 
        }

        //Verifying student Account account



        [HttpGet]
        public ActionResult addModules()
        {
            return View();
        }

        [HttpPost]
        //Adding Modules
        public ActionResult addModules(Student stu)
        {
            connectionString();

            
            SqlDataAdapter da = new SqlDataAdapter("EnterModules",connect);

            connect.Open();

            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@moduleCode", SqlDbType.VarChar, 15).Value = stu.moduleCode;
            da.SelectCommand.Parameters.Add("@moduleName", SqlDbType.VarChar, 30).Value = stu.moduleName;
            da.SelectCommand.Parameters.Add("@credits", SqlDbType.Int).Value = stu.credits;
            da.SelectCommand.Parameters.Add("@hours", SqlDbType.Decimal).Value = stu.hours;
            da.SelectCommand.Parameters.Add("@weeks", SqlDbType.Decimal).Value = stu.weeks;
            da.SelectCommand.Parameters.Add("@startOfSemester", SqlDbType.Date).Value = stu.startOfSemester;
            da.SelectCommand.Parameters.Add("@endOfSemester", SqlDbType.Date).Value = stu.endOfSemester;
            da.SelectCommand.Parameters.Add("@selfStudy", SqlDbType.Decimal).Value = stu.selfStudy;
            da.SelectCommand.Parameters.Add("@moduleHours", SqlDbType.Decimal).Value = stu.moduleHours;
            da.SelectCommand.Parameters.Add("@moduleDate", SqlDbType.Date).Value = stu.moduleDate;
            da.SelectCommand.Parameters.Add("@hoursRemaining", SqlDbType.Decimal).Value = stu.hoursRemaining;
            da.SelectCommand.Parameters.Add("@username", SqlDbType.VarChar,20).Value = stu.username;
            //calculation to get self study hours per week
            //stu.selfStudy = stu.credits * 10 / stu.weeks - stu.hours;
            da.SelectCommand.ExecuteNonQuery();
            connect.Close();

            MessageBox.Show("Module Information Inserted successfully.");
            return View("addModules");
        }


        [HttpGet]
        public ActionResult graph()
        {
            return View();
        }

        [HttpPost]
        //Displaying graph
        public ActionResult graph(Student stu)
        {
            string query ="Select moduleName, moduleHours from Modules" ;

            string connectString = "Data Source=(localdb)\\ProjectsV13;Initial Catalog=TimeManagement;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            List<Student> graphData = new List<Student>();

            using (SqlConnection connect = new SqlConnection(connectString))
            {
                using(SqlCommand command = new SqlCommand(query))
                {
                    command.CommandType = CommandType.Text;
                    command.Connection = connect;
                    connect.Open();

                    using (SqlDataReader read = command.ExecuteReader())
                    {
                        while (read.Read())
                        {
                            graphData.Add(new Student
                                {
                                moduleName = read["moduleName"].ToString(), moduleHours = Convert.ToInt32(read["moduleHours"])
                                    
                                    });

                        }

                    }
                    connect.Close();

                }


            }
            return View(graphData);


        }

    }
}