My Read me file: ST10245588 Lemogang Moloko 01/12/2022
1. My Instructions of my dtabase :
Step 1: Download the zipped file from RC Learn or One Drive.
Step 2: Extract the project named ST10245588_LEMOGANG MOLOKO_ST10245588_Prog6222_ProgPOE from the Zipped Folder and save it on your PC.
Step 3: Launch Visual Studio.
Step 4: After launching Visual studio select Open Local Folder
Step 5: Access the project where it was saved on the PC
Step 6: Open the SQL File titled TimeManagement using Microsoft SQL Management Studio.
Step 7: Execute the 'Create Table' statements.
Step 8 :Establish the connection and ensure that it is sucessful , if it is not sucessful , refresh the connection string 
Step 9: Return to Visual Studio then go to Server Explorer and refresh the connection between the server and the program.
Step 10: Click start execute the project.
Step 11: The program will now run in order to execute its functions.
Step 12: You have now successfully accessed and executed your web application.
 

2. Errors that can expected when launching the program:
There are no errors that can be expected in during the run of this program, however Framework errors may occur during the course of the application.
3. How to solve the framework errors:
 1: navigate to the bottom of the build Output window, and proceed to click on the Error List tab that is displayed 
 2: By completing step 1 you will be provided with a clearer view of any errors that will be experienced throughout the project.
 3: For direct access of the error and the line that the error occurs on, it is advised to click on the error line that is shown in the Error List window.
 4: Upon accessing the error, it can be identified by a red line. 
 5: Once that appears you may now works towards fixing the error.
 6: Once clean-up of the code has been successfully performed, you may now can run the project by doing the following: selecting Debug > Start Debugging, which will then start the project and provide a detailed view of the project within the debug environment.

